function isPrime(value) {
	var ans = [];
	if(ans[value] != null) {
		return ans[value];
	}
	for(var i =2; i<value; i++) {
		if(value % i == 0) {
			ans[value] = false
			return false;
		}
	}
	ans[value] = value > 1;
	return ans[value]
}